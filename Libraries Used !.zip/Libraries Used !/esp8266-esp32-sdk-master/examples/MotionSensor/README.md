# Tutorials

1. [Motion Sensor Tutorial for HC-SR501, HC-SR505, Mini AM312, HC-SR312
](https://help.sinric.pro/pages/tutorials/motion-sensors/HC-SR501-HC-SR505-AM312-HC-SR312)
