# Tutorials

1. [Light Tutorial for LED Light Strip RGB 5050](https://help.sinric.pro/pages/tutorials/light/LED-Stripe-5050)
 

