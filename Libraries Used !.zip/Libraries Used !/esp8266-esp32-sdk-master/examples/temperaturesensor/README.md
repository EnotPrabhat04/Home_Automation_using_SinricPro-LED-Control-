# Tutorials

1. [DHT11 and DHT22, AM2302, RHT03](https://help.sinric.pro/pages/tutorials/temperature-sensors/DHTx_AMx_RHTx)

2. [DS18B20 and DS1822, DS1820, MAX31820, MAX31850](https://help.sinric.pro/pages/tutorials/temperature-sensors/DS18B20)

3. [LM35 (LM35DZ), LM335 and LM34](https://help.sinric.pro/pages/tutorials/temperature-sensors/LMx)

4. [BME280](https://help.sinric.pro/pages/tutorials/temperature-sensors/BME280)

5. [BMP180](https://help.sinric.pro/pages/tutorials/temperature-sensors/BMP180)


