# Tutorials

1. [Contact Sensor Tutorial for ESP8266, ESP32, Raspberry Pi Pico W](https://help.sinric.pro/pages/tutorials/contact-sensors/contact)
 
